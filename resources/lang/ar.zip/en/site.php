<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */
// en
    'rent' => 'rent',
    'sell' => 'sell',
    'wanted' => 'wanted',
    'shop'=>'shop',
    'password'=>'Password',
    'login'=>'Login',
    'forgitPassword'=>'Are You Forget Password?',
    'email'=>'Email Address',
        'Select_country'=>'Select Country'


];
