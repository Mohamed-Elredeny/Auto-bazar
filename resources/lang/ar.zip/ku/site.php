<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */
// ku
    'rent' => 'rent',
    'sell' => 'sell',
    'wanted' => 'wanted',
    'shop'=>'متجر',
    'password'=>'ژمارةى نهينى',
    'login'=>'چوونەژوورەوە',
    'forgitPassword'=>'ئایا ژمارةى نهينيت لەبیرچووە؟',
    'email'=>'ناونیشانی ئیمەیڵ' ,
        'Select_country'=>'وڵات دیاریبکە'

];
